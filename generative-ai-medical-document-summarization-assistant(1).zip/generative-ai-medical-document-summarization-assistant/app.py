import streamlit as st
from src.document_loader import load_uploaded_file
from src.summarizer import MedicalSummarizer

st.set_page_config(page_title="Medical Document Summarization Assistant", page_icon="🩺", layout="wide")

st.title("🩺 Generative AI-Based Medical Document Summarization Assistant")
st.caption("Educational/research prototype for summarizing de-identified medical documents.")

@st.cache_resource
def get_summarizer():
    return MedicalSummarizer()

summarizer = get_summarizer()

uploaded = st.file_uploader(
    "Upload a medical document",
    type=["txt", "pdf", "csv"],
    help="Use synthetic or properly authorized/de-identified data only."
)

text = st.text_area(
    "Or paste a medical document",
    height=260,
    placeholder="Paste a de-identified clinical note here..."
)

if uploaded is not None:
    try:
        text = load_uploaded_file(uploaded)
        st.info(f"Loaded {len(text):,} characters from {uploaded.name}.")
    except Exception as exc:
        st.error(f"Could not read the uploaded file: {exc}")

if st.button("Generate Summary", type="primary", disabled=not bool(text.strip())):
    with st.spinner("Generating summary..."):
        try:
            summary = summarizer.summarize(text)
            st.subheader("Generated Summary")
            st.markdown(summary)

            st.download_button(
                "Download Summary",
                data=summary,
                file_name="medical_summary.txt",
                mime="text/plain"
            )
        except Exception as exc:
            st.error(f"Summarization failed: {exc}")

st.divider()
st.warning(
    "Do not upload identifiable patient information. This prototype is for education/research "
    "and must not be used as the sole basis for clinical decisions."
)
