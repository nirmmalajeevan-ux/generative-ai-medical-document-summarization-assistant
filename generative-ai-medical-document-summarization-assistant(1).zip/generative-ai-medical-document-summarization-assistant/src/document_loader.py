from io import BytesIO
import pandas as pd
from pypdf import PdfReader

def load_uploaded_file(uploaded_file) -> str:
    name = uploaded_file.name.lower()
    raw = uploaded_file.getvalue()

    if name.endswith(".txt"):
        return raw.decode("utf-8", errors="ignore")

    if name.endswith(".pdf"):
        reader = PdfReader(BytesIO(raw))
        return "\n".join(page.extract_text() or "" for page in reader.pages)

    if name.endswith(".csv"):
        df = pd.read_csv(BytesIO(raw))
        return df.to_csv(index=False)

    raise ValueError("Unsupported file type.")
