from transformers import pipeline

class MedicalSummarizer:
    def __init__(self, model_name: str = "facebook/bart-large-cnn"):
        self.model_name = model_name
        self.pipe = pipeline("summarization", model=model_name)

    @staticmethod
    def _chunks(text: str, max_words: int = 650):
        words = text.split()
        for i in range(0, len(words), max_words):
            yield " ".join(words[i:i + max_words])

    def _summarize_chunk(self, chunk: str) -> str:
        result = self.pipe(
            chunk,
            max_length=180,
            min_length=45,
            do_sample=False,
            truncation=True,
        )
        return result[0]["summary_text"]

    def summarize(self, text: str) -> str:
        text = " ".join(text.split())
        if not text:
            return "No document text was provided."

        partial = [self._summarize_chunk(c) for c in self._chunks(text)]
        combined = " ".join(partial)

        # A second pass keeps the final result concise when there are many chunks.
        if len(partial) > 1 and len(combined.split()) > 450:
            combined = self._summarize_chunk(combined)

        return (
            "### Clinical Summary\n"
            f"{combined}\n\n"
            "### Important Note\n"
            "This summary is AI-generated and should be checked against the source document. "
            "It is not a diagnosis or treatment recommendation."
        )
