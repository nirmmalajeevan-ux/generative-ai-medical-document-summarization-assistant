# Generative AI-Based Medical Document Summarization Assistant

A Streamlit-based Generative AI application that converts long medical documents into concise, structured summaries.

## Features
- Paste medical text or upload a `.txt`, `.pdf`, or `.csv` file
- Automatic document chunking for long notes
- Generative summarization with Hugging Face Transformers
- Structured output: Clinical Summary, Diagnoses/Conditions, Medications, Investigations, Procedures, Follow-up
- Download the generated summary as a text file
- Synthetic demo data included so the repository runs without restricted clinical data

## Dataset

Recommended research dataset: **MIMIC-IV-Note**, which contains de-identified clinical notes including discharge summaries and radiology reports. Access is credentialed through PhysioNet and requires the applicable training and Data Use Agreement.

- PhysioNet MIMIC-IV: https://www.physionet.org/content/mimiciv/
- MIMIC-IV access guide: https://mimic.mit.edu/docs/faq/how-to-get-access.html
- EHR-DS-QA synthetic QA dataset derived from MIMIC discharge summaries: https://www.physionet.org/content/ehr-ds-qa/1.0.0/

**Important:** Do not commit restricted MIMIC data to this GitHub repository. Store authorized data locally under `data/private/` and keep that directory ignored by Git.

## Project Structure

```text
generative-ai-medical-document-summarization-assistant/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── LICENSE
├── data/
│   └── sample_medical_notes.csv
├── src/
│   ├── __init__.py
│   ├── summarizer.py
│   └── document_loader.py
├── scripts/
│   └── preprocess.py
└── tests/
    └── test_summarizer.py
```

## Installation

```bash
git clone <YOUR_GITHUB_REPOSITORY_URL>
cd generative-ai-medical-document-summarization-assistant

python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

The first run downloads the Hugging Face model `facebook/bart-large-cnn`.

## Example Workflow

1. Upload a de-identified clinical document.
2. The application extracts the text.
3. Long documents are split into manageable chunks.
4. The generative model summarizes each chunk.
5. Chunk summaries are combined into a final structured summary.
6. The user can download the result.

## Evaluation

For research evaluation, compare generated summaries with reference summaries using:
- ROUGE-1
- ROUGE-2
- ROUGE-L
- BERTScore
- Clinician review for factual consistency and omission of important information

Automated metrics alone should not be treated as proof of clinical safety.

## Medical Safety Notice

This is an educational/research prototype, not a medical device and not a substitute for a qualified clinician. Generated summaries may contain omissions or errors. Never use the output as the sole basis for diagnosis, treatment, medication changes, or other clinical decisions.

## License

MIT License.
