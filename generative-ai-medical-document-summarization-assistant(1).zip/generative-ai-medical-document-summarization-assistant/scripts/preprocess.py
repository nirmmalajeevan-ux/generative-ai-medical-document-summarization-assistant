from pathlib import Path
import pandas as pd

INPUT = Path("data/sample_medical_notes.csv")
OUTPUT = Path("data/processed_notes.csv")

def main():
    df = pd.read_csv(INPUT)
    df["clean_text"] = df["note"].fillna("").astype(str).str.replace(r"\s+", " ", regex=True).str.strip()
    df.to_csv(OUTPUT, index=False)
    print(f"Saved {len(df)} records to {OUTPUT}")

if __name__ == "__main__":
    main()
