from src.summarizer import MedicalSummarizer

def test_chunking():
    chunks = list(MedicalSummarizer._chunks("one two three four five", max_words=2))
    assert chunks == ["one two", "three four", "five"]
